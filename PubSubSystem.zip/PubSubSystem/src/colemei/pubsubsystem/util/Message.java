package colemei.pubsubsystem.util;

/**
 * The Message class represents a message object in the publish-subscribe system.
 * It encapsulates message details such as the topic, content, and timestamp for 
 * sending messages between publishers and subscribers.
 * 
 * @author QIYUE MEI 1554024
 */

public class Message {
    
    private String topicID;
    private String content;
    private String timestamp;

    // Constructor
    public Message(String topicID, String content, String timestamp) {
        this.topicID = topicID;
        this.content = content;
        this.timestamp = timestamp;
    }

    // Getters and setters
    public String getTopicID() {
        return topicID;
    }

    public String getContent() {
        return content;
    }

    public String getTimestamp() {
        return timestamp;
    }
}
