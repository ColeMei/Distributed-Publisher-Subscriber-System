package colemei.pubsubsystem.util;

/**
 * The Constants class defines various constants used throughout the publish-subscribe 
 * system, such as the Directory Service URL and other configuration parameters.
 * 
 * @author QIYUE MEI 1554024
 */

public class Constants {
    
    // Default port and URL for the Directory Service
    public static final int DEFAULT_PORT = 1099;
    public static final String DIRECTORY_SERVICE_URL = "//localhost/DirectoryService";

    // Add other constants as needed
}
