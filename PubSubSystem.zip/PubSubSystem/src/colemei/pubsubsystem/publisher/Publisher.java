package colemei.pubsubsystem.publisher;

/**
 * The Publisher class represents a publisher in the publish-subscribe system.
 * It interacts with the broker to register topics, publish messages, and manage 
 * its topics. It also handles graceful shutdown and crash detection.
 * 
 * @author QIYUE MEI 1554024
 */

import colemei.pubsubsystem.broker.BrokerInterface;
import colemei.pubsubsystem.directory.DirectoryServiceInterface;
import colemei.pubsubsystem.util.Constants;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.util.List;
import java.util.Scanner;
import java.util.UUID;

public class Publisher {

    private String username;
    private BrokerInterface connectedBroker;
    private DirectoryServiceInterface directoryService;

    private final Scanner scanner = new Scanner(System.in);

    private boolean gracefulExit = false;  // Flag to track if the exit was graceful

    // Constructor
    public Publisher(String username) {
        this.username = username;
        connectToDirectoryService();
    }

    // Connect to the Directory Service
    private void connectToDirectoryService() {
        try {
            directoryService = (DirectoryServiceInterface) Naming.lookup(Constants.DIRECTORY_SERVICE_URL);
            System.out.println("[SUCCESS] Connected to Directory Service");
        } catch (Exception e) {
            System.out.println("[ERROR] Failed to connect to Directory Service.");
            e.printStackTrace();
        }
    }

    // Connect to the least busy broker
    private void connectToBroker() {
        try {
            // Retrieve the least busy broker as a String array [brokerID, brokerAddress]
            String[] availableBroker = directoryService.getLeastBusyBroker();
    
            // Debugging: print out the least busy broker
            if (availableBroker != null) {
                String brokerID = availableBroker[0];  // Extract brokerID
                String brokerAddress = availableBroker[1];  // Extract brokerAddress
    
                connectedBroker = (BrokerInterface) Naming.lookup("//" + brokerAddress + "/BrokerService");

                // Register this publisher with the broker
                connectedBroker.registerPublisher(username);
    
                // Inform DirectoryService that a new connection has been made
                directoryService.increaseConnectionCount(brokerID);
    
                System.out.println("[SUCCESS] " + username + " connected to broker: " + brokerID + " at address: " + brokerAddress);
            } else {
                System.out.println("[ERROR] No available brokers at the moment." );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // List available brokers and let the publisher choose one to connect
    private void listAvailableBrokers() {
        try {
            // Retrieve the list of available brokers as a list of String arrays [brokerID, brokerAddress]
            List<String[]> brokers = directoryService.getAvailableBrokers();
            
            if (brokers.isEmpty()) {
                System.out.println("[INFO] No available brokers at the moment.");
                return;
            }

            System.out.println("[INFO] Available brokers:");
            for (int i = 0; i < brokers.size(); i++) {
                String[] broker = brokers.get(i);
                System.out.println(i + 1 + ". Broker ID: " + broker[0] + ", Address: " + broker[1]);
            }

            // Prompt the publisher to select a broker
            System.out.print("> Select a broker to connect (enter the index): ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume the newline

            if (choice > 0 && choice <= brokers.size()) {
                String brokerID = brokers.get(choice - 1)[0];
                String brokerAddress = brokers.get(choice - 1)[1];
                connectToSpecifiedBroker(brokerID, brokerAddress);
            } else {
                System.out.println("[ERROR] Invalid selection.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Connect to the specified broker by name
    private void connectToSpecifiedBroker(String brokerName) {
        try {
            // Retrieve the broker's address from the Directory Service by name
            String[] brokerInfo = directoryService.getBrokerInfoByName(brokerName);

            if (brokerInfo != null) {
                String brokerID = brokerInfo[0];
                String brokerAddress = brokerInfo[1];

                connectedBroker = (BrokerInterface) Naming.lookup("//" + brokerAddress + "/BrokerService");

                // Register this publisher with the broker
                connectedBroker.registerPublisher(username);

                // Inform DirectoryService that a new connection has been made
                directoryService.increaseConnectionCount(brokerID);

                System.out.println("[SUCCESS] " + username + " connected to broker: " + brokerID + " at address: " + brokerAddress);
            } else {
                System.out.println("[ERROR] No broker found with the name: " + brokerName);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Overloaded connectToSpecifiedBroker method for broker ID and address directly
    private void connectToSpecifiedBroker(String brokerID, String brokerAddress) {
        try {
            connectedBroker = (BrokerInterface) Naming.lookup("//" + brokerAddress + "/BrokerService");

            // Register this publisher with the broker
            connectedBroker.registerPublisher(username);

            // Inform DirectoryService that a new connection has been made
            directoryService.increaseConnectionCount(brokerID);

            System.out.println("[SUCCESS] " + username + " connected to broker: " + brokerID + " at address: " + brokerAddress);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }   

    // Console interface for the Publisher
    private void runConsoleInterface() {

    // Register the shutdown hook to detect forceful termination (like Ctrl+C)
    Runtime.getRuntime().addShutdownHook(new Thread(() -> {
        try {
            // If this is a forceful shutdown (not via the "exit" command)
            if (!gracefulExit) {
                System.out.println();
                System.out.println("[INFO] Publisher " + username + " is shutting down unexpectedly. Notifying broker...");
                connectedBroker.handlePublisherCrash(username);  // Notify the broker about the crash
            }
        } catch (RemoteException e) {
            System.out.println("[ERROR] Failed to notify broker about publisher crash.");
            e.printStackTrace();
        }
    }));

        while (true) {
            System.out.println("\nPlease select a command: create, publish, show, delete, or exit.");
            System.out.println("1. create {topic_name}             # Create a new topic");
            System.out.println("2. publish {topic_id} {message}    # Publish a message to an existing topic");
            System.out.println("3. show                            # Show subscriber count for current publisher");
            System.out.println("4. delete {topic_id}               # Delete a topic");
            System.out.println("5. exit                            # Exit the publisher");
            System.out.print("> Enter command: ");

            String command = scanner.nextLine().trim();

            switch (command.split(" ")[0]) {
                case "create":
                    handleCreateTopic(command);
                    break;
                case "publish":
                    handlePublishMessage(command);
                    break;
                case "show":
                    handleShowSubscribers();
                    break;
                case "delete":
                    handleDeleteTopic(command);
                    break;
                case "exit":
                    handleExit();
                    return;
                default:
                    System.out.println("[ERROR] Invalid command.");
            }
        }
    }

    // Create a new topic
    private void handleCreateTopic(String command) {
        try {
            // Parse command to get topic name
            String[] parts = command.split(" ");
            if (parts.length != 2) {
                System.out.println("[ERROR] Invalid command format. Use: create {topic_name}");
                return;
            }
            String topicName = parts[1];
            String topicID = UUID.randomUUID().toString();  // Generate unique topic ID
    
            // Register the topic with the broker
            connectedBroker.registerTopic(topicID, topicName, username);
            System.out.println("[SUCCESS] Topic created with ID: " + topicID + ", Name: " + topicName);
        } catch (RemoteException e) {
            System.out.println("[ERROR] Could not create topic.");
            e.printStackTrace();
        }catch (Exception e) {
            System.out.println("[ERROR] Could not create topic.");
            e.printStackTrace();
        }
    }

    // Publish a message to a topic
    private void handlePublishMessage(String command) {
        try {
            // Parse command to get topic ID and message
            String[] parts = command.split(" ", 3);
            if (parts.length != 3) {
                System.out.println("[ERROR] Invalid command format. Use: publish {topic_id} {message}");
                return;
            }
            String topicID = parts[1];
            String message = parts[2];
    
            // Ensure the message length is less than or equal to 100 characters
            if (message.length() > 100) {
                System.out.println("[ERROR] Message exceeds 100 characters limit.");
                return;
            }
    
            // Publish the message via the broker and retrieve messages for subscribers
            connectedBroker.publishMessage(topicID, message, username);
            System.out.println("[SUCCESS] Message published to topic: " + topicID);
        } catch (RemoteException e) {
            // Handle different RemoteException cases based on the message
            String errorMessage = e.getMessage();
            if (errorMessage.contains("does not exist")) {
                System.out.println("[ERROR] " + errorMessage);
            } else if (errorMessage.contains("do not have permission")) {
                System.out.println("[ERROR] " + errorMessage);
            } else {
                // General RemoteException handler
                System.out.println("[ERROR] Failed to publish the message due to a remote error.");
                e.printStackTrace();
            }
        } catch (Exception e) {
            // General exception handler for any other unexpected issues
            System.out.println("[ERROR] An unexpected error occurred.");
            e.printStackTrace();
        }
    }
    
    // Show the subscriber count for each topic owned by the publisher
    private void handleShowSubscribers() {
        try {
            // Request the broker to get the subscriber count for each topic owned by this publisher
            List<String[]> topicSubscriberCounts = connectedBroker.getSubscriberCountForPublisher(username);
            if (topicSubscriberCounts.isEmpty()) {
                System.out.println("[SUCCESS] No topics to show.");
            } else {
                System.out.println("[SUCCESS] Subscriber count for each topic:");
                for (String[] topicInfo : topicSubscriberCounts) {
                    System.out.println("Topic ID: " + topicInfo[0] + ", Topic Name: " + topicInfo[1] + ", Subscribers: " + topicInfo[2]);
                }
            }
        } catch (RemoteException e) {
            System.out.println("[ERROR] Could not retrieve subscriber counts.");
            e.printStackTrace();
        } catch (Exception e) {
            System.out.println("[ERROR] Could not retrieve subscriber counts.");
            e.printStackTrace();
        }
    }
    
    // Delete a topic owned by the publisher
    private void handleDeleteTopic(String command) {
        try {
            // Parse command to get topic ID
            String[] parts = command.split(" ");
            if (parts.length != 2) {
                System.out.println("[ERROR] Invalid command format. Use: delete {topic_id}");
                return;
            }
            String topicID = parts[1];
    
            // Request the broker to delete the topic
            connectedBroker.deleteTopic(topicID, username);
            System.out.println("[SUCCESS] Topic deleted: " + topicID);
        } catch (RemoteException e) {
            // Handle different RemoteException cases based on the message
            String errorMessage = e.getMessage();
            if (errorMessage.contains("does not exist")) {
                System.out.println("[ERROR] " + errorMessage);
            } else if (errorMessage.contains("do not have permission")) {
                System.out.println("[ERROR] " + errorMessage);
            } else {
                // General RemoteException handler
                System.out.println("[ERROR] Failed to delete the topic due to a remote error.");
                e.printStackTrace();
            }
        } catch (Exception e) {
            // General exception handler for any other unexpected issues
            System.out.println("[ERROR] An unexpected error occurred.");
            e.printStackTrace();
        }
    }
    
    // Gracefully exit the publisher
    private void handleExit() {
        try {
            if (connectedBroker != null) {
                gracefulExit = true;  // Mark as graceful exit
                connectedBroker.unregisterPublisher(username);
                System.out.println("[SUCCESS] Successfully unregistered from broker.");
            }
            System.out.println("Exiting...");
        } catch (RemoteException e) {
            System.out.println("[ERROR] Error during unregistering with broker.");
            e.printStackTrace();

        }catch (Exception e) {
            System.out.println("[ERROR] Error during unregistering with broker.");
            e.printStackTrace();
        }
        System.exit(0);  // Normal exit
    }
    
    // Main method to run the Publisher
    public static void main(String[] args) {
        try {
            if (args.length < 1 || args.length > 3) {
                System.out.println("[ERROR] Usage:");
                System.out.println("  java -jar publisher.jar <username>                      # Auto-connect to least busy broker");
                System.out.println("  java -jar publisher.jar <username> <-list>              # List available brokers");
                System.out.println("  java -jar publisher.jar <username> <brokername>         # Connect to specified broker");
                return;
            }

            String username = args[0];
            Publisher publisher = new Publisher(username);

            if (args.length == 1) {
                // Auto-connect to least busy broker
                publisher.connectToBroker();
            } else if (args.length == 2 && args[1].equals("-list")) {
                // List available brokers
                publisher.listAvailableBrokers();
            } else if (args.length == 2) {
                // Connect to specified broker
                String brokerName = args[1];
                publisher.connectToSpecifiedBroker(brokerName);
            }

            // Run the console interface
            publisher.runConsoleInterface();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }   
}
