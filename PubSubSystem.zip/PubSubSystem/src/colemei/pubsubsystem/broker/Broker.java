package colemei.pubsubsystem.broker;

/**
 * The Broker class implements the BrokerInterface and handles the registration of 
 * publishers and subscribers, topic management, and message propagation.
 * It is responsible for managing local subscribers and publishers as well as 
 * synchronizing with other brokers in the distributed network.
 * 
 * @author QIYUE MEI 1554024
 */


import colemei.pubsubsystem.directory.DirectoryServiceInterface;
import colemei.pubsubsystem.subscriber.SubscriberCallbackInterface;
import colemei.pubsubsystem.util.Constants;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Broker extends UnicastRemoteObject implements BrokerInterface {

    private String brokerID;
    private String brokerAddress;
    private DirectoryServiceInterface directoryService;

    // Store references to remote brokers
    private Map<String, BrokerInterface> connectedBrokers;

    // Map of topics registered with this broker (topicID -> topicName)
    private Map<String, String> topics = new HashMap<>();

    // Map of topics registered with other brokers (topicID -> topicName, publisherName)
    private Map<String, String[]> remoteTopics = new HashMap<>();

    // Map of publishers and their topics (publisherID -> Set of topicIDs)
    private Map<String, Set<String>> publisherTopics = new HashMap<>();

    // Map of subscribers and their subscriptions (subscriberID -> Set of topicIDs)
    private Map<String, Set<String>> subscriberTopics = new HashMap<>();

    // Map of subscribers and their callback interfaces (subscriberID -> SubscriberCallbackInterface)
    private Map<String, Set<SubscriberCallbackInterface>> topicSubscribers = new HashMap<>();

    // List of active publishers connected to this broker
    private Set<String> activePublishers = new HashSet<>();  // Initialize the Set

    // List of active subscribers connected to this broker
    private Set<String> activeSubscribers = new HashSet<>();  // Initialize the Set

    public Broker(String brokerID, String brokerAddress) throws RemoteException {
        super();
        this.brokerID = brokerID;
        this.brokerAddress = brokerAddress;
        this.connectedBrokers = new HashMap<>();
    }

    // Helper method to get the current timestamp
    private static String getCurrentTimeStamp() {
        return new SimpleDateFormat("dd/MM HH:mm:ss").format(new Date());
    }

    // Register with Directory Service and get a map of other brokers (brokerID -> brokerAddress)
    public void registerWithDirectoryService() {
        try {
            directoryService = (DirectoryServiceInterface) Naming.lookup(Constants.DIRECTORY_SERVICE_URL);

            // Register this broker
            directoryService.registerBroker(brokerID, brokerAddress);
            String timeStamp = getCurrentTimeStamp();
            System.out.println("========================================");
            System.out.println(String.format("[%s] [INFO] Broker %s registered at %s", timeStamp, brokerID, brokerAddress));
            System.out.println("========================================");

            // Get map of other brokers (brokerID -> brokerAddress) and establish connections
            Map<String, String> otherBrokers = directoryService.getRegisteredBrokers();

            // Debugging: print out the list of other brokers
            // for (Map.Entry<String, String> brokerEntry : otherBrokers.entrySet()) {
            //     System.out.println("Broker: " + brokerEntry.getKey() + " at address: " + brokerEntry.getValue());
            // }

            connectToOtherBrokers(otherBrokers);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Establish connection with other brokers via RMI and store the connection
    private void connectToOtherBrokers(Map<String, String> otherBrokers) {
        for (Map.Entry<String, String> brokerEntry : otherBrokers.entrySet()) {
            String remoteBrokerID = brokerEntry.getKey();
            String remoteBrokerAddress = brokerEntry.getValue();

            if (!remoteBrokerAddress.equals(brokerAddress)) { // Compare with class-level brokerAddress
                try {
                    String timeStamp = getCurrentTimeStamp();
                    System.out.println("========================================");
                    System.out.println(String.format("[%s] [INFO] Connecting to broker: %s at address: %s", timeStamp, remoteBrokerID, remoteBrokerAddress));
                    System.out.println("========================================");

                    BrokerInterface remoteBroker = (BrokerInterface) Naming.lookup("//" + remoteBrokerAddress + "/BrokerService");
                    
                    // Store the reference to the connected broker for future use
                    connectedBrokers.put(remoteBrokerID, remoteBroker);

                    // Send a test message to the remote broker
                    // remoteBroker.sendTestMessage("Hello from broker: " + brokerAddress);  // Use class-level brokerAddress

                    // Notify the existing broker about the new broker
                    remoteBroker.addBroker(brokerID, brokerAddress);  // Use class-level brokerID and brokerAddress

                    // System.out.println("Test message sent and broker notified: " + remoteBrokerID);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    // Register a new publisher
    @Override
    public synchronized void registerPublisher(String publisherID) throws RemoteException {
        activePublishers.add(publisherID);
        String timeStamp = getCurrentTimeStamp();
        System.out.println("========================================");
        System.out.println(String.format("[%s] [INFO] Publisher %s is now active on broker %s", timeStamp, publisherID, brokerID));
        System.out.println("========================================");

    }

    // Register a new subscriber
    @Override
    public synchronized void registerSubscriber(String subscriberID) throws RemoteException {
        activeSubscribers.add(subscriberID);
        String timeStamp = getCurrentTimeStamp();
        System.out.println("========================================");
        System.out.println(String.format("[%s] [INFO] Subscriber %s is now active on broker %s", timeStamp, subscriberID, brokerID));
        System.out.println("========================================");

    }

    // Unregister a publisher
    @Override
    public synchronized void unregisterPublisher(String publisherID) throws RemoteException {
        if (activePublishers.contains(publisherID)) {
            activePublishers.remove(publisherID);
            
            String timeStamp = getCurrentTimeStamp();
            System.out.println("========================================");
            System.out.println(String.format("[%s] [INFO] Publisher unregistered: %s", timeStamp, publisherID));
            System.out.println("========================================");

            directoryService.decreaseConnectionCount(brokerID);
        } else {
            String timeStamp = getCurrentTimeStamp();
            System.out.println("========================================");
            System.out.println(String.format("[%s] [ERROR] Publisher not found: %s", timeStamp, publisherID));
            System.out.println("========================================");

        }
    }

    // Unregister a subscriber
    @Override
    public synchronized void unregisterSubscriber(String subscriberID) throws RemoteException {
        if (activeSubscribers.contains(subscriberID)) {
            activeSubscribers.remove(subscriberID);
            String timeStamp = getCurrentTimeStamp();
            System.out.println("========================================");
            System.out.println(String.format("[%s] [INFO] Subscriber unregistered: %s", timeStamp, subscriberID, brokerID));
            System.out.println("========================================");

            directoryService.decreaseConnectionCount(brokerID);
        } else {
            String timeStamp = getCurrentTimeStamp();
            System.out.println("========================================");
            System.out.println(String.format("[%s] [ERROR] Subscriber not found: %s", timeStamp, subscriberID));
            System.out.println("========================================");
        }
    }

    // Register a new topic
    @Override
    public synchronized void registerTopic(String topicID, String topicName, String publisherName) throws RemoteException {
        // Store topic in the topics map (topicID -> topicName)
        topics.put(topicID, topicName);

        // Associate topic with the publisher
        publisherTopics.computeIfAbsent(publisherName, k -> new HashSet<>()).add(topicID);

        String timeStamp = getCurrentTimeStamp();
        System.out.println(String.format("[%s] [SUCCESS] Topic registered: %s (%s) by Publisher: %s", timeStamp, topicID, topicName, publisherName));

        // Add this topic to the other brokers' remoteTopics map
        for (Map.Entry<String, BrokerInterface> entry : connectedBrokers.entrySet()) {
            BrokerInterface remoteBroker = entry.getValue();
            try {
                // Inform the remote broker about the new topic
                remoteBroker.addRemoteTopic(topicID, topicName, publisherName);
            } catch (RemoteException e) {
                System.out.println("[ERROR] Failed to register topic with broker " + entry.getKey());
                e.printStackTrace();
            }
        }
    }

    // Add a remote topic from another broker
    @Override
    public synchronized void addRemoteTopic(String topicID, String topicName, String publisherName) throws RemoteException {
        // Store the topic and publisher in the remoteTopics map
        remoteTopics.put(topicID, new String[]{topicName, publisherName});
    }

    // Delete a topic and notify subscribers
    @Override
    public synchronized void deleteTopic(String topicID, String publisherID) throws RemoteException {
        // Ensure the topic exists
        if (!remoteTopics.containsKey(topicID) && !topics.containsKey(topicID)) {
            throw new RemoteException("Topic " + topicID + " does not exist.");
        }
    
        // Check if the topic belongs to the current publisher
        Set<String> publisherTopicList = publisherTopics.get(publisherID);
        if (publisherTopicList == null || !publisherTopicList.contains(topicID)) {
            throw new RemoteException("You do not have permission to delete this topic.");
        }
    
        // Get the current timestamp in the format [dd/mm hh:mm:ss]
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM HH:mm:ss");
        String currentTime = sdf.format(new Date());

        // Retrieve the topic name from the topicID (assuming you have a way to get the topic name)
        String topicName = topics.getOrDefault(topicID, "Unknown Topic");

        String deletionMessage = String.format("[%s] [%s : %s : %s] Topic has been deleted by Publisher %s.", currentTime, topicID, topicName, publisherID, publisherID);
        
        // Notify all subscribers in real-time about topic deletion
        Set<SubscriberCallbackInterface> subscribers = topicSubscribers.getOrDefault(topicID, new HashSet<>());
        for (SubscriberCallbackInterface subscriber : subscribers) {
            try {
                // Send the formatted message to the subscriber
                subscriber.receiveMessage(deletionMessage);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }

        // Now propagate the message to all connected brokers for global synchronization
        propagateMessageToOtherBrokers(topicID, deletionMessage, publisherID);
    
        // Remove the topic from the topics list
        topics.remove(topicID);
    
        // Remove the topic from the publisher's topic list
        publisherTopicList.remove(topicID);
    
        // Unsubscribe all subscribers from this topic
        for (Map.Entry<String, Set<String>> entry : subscriberTopics.entrySet()) {
            Set<String> subscriptions = entry.getValue();
            subscriptions.remove(topicID);  // Remove this topic from the subscriber's subscription list
        }
    
        // Clean up the topic-subscriber mapping
        topicSubscribers.remove(topicID);

        // Inform the other brokers about the topic deletion
        for (Map.Entry<String, BrokerInterface> entry : connectedBrokers.entrySet()) {
            BrokerInterface remoteBroker = entry.getValue();
            try {
                // Use the deleteRemoteTopic method to delete the topic from the remote broker
                remoteBroker.deleteRemoteTopic(topicID);
            } catch (RemoteException e) {
                System.out.println("[ERROR] Failed to delete topic with broker " + entry.getKey());
                e.printStackTrace();
            }
        }
    
        String timeStamp = getCurrentTimeStamp();
        System.out.println(String.format("[%s] [SUCCESS] Topic %s deleted and all subscribers unsubscribed.", timeStamp, topicID));
    }

    // Delete a remote topic from another broker
    @Override
    public synchronized void deleteRemoteTopic(String topicID) throws RemoteException {
        // Ensure the topic exists
        if (!remoteTopics.containsKey(topicID)) {
            throw new RemoteException("Topic " + topicID + " does not exist.");
        }

        // Remove the topic from the remote topics list
        remoteTopics.remove(topicID);
    
        // Unsubscribe all subscribers from this topic
        for (Map.Entry<String, Set<String>> entry : subscriberTopics.entrySet()) {
            Set<String> subscriptions = entry.getValue();
            subscriptions.remove(topicID);  // Remove this topic from the subscriber's subscription list
        }
    
        // Clean up the topic-subscriber mapping
        topicSubscribers.remove(topicID);
    }
    
    @Override
    public synchronized void publishMessage(String topicID, String message, String publisherID) throws RemoteException {
        // Ensure the topic exists
        if (!remoteTopics.containsKey(topicID) && !topics.containsKey(topicID)) {
            throw new RemoteException("[error] Topic " + topicID + " does not exist.");
        }

        // Check if the topic belongs to the current publisher
        Set<String> publisherTopicList = publisherTopics.get(publisherID);
        if (publisherTopicList == null || !publisherTopicList.contains(topicID)) {
            throw new RemoteException("You do not have permission to publish on this topic.");
        }

        // Get the current timestamp in the format [dd/MM HH:mm:ss]
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM HH:mm:ss");
        String currentTime = sdf.format(new Date());

        // Retrieve the topic name from the topicID (assuming you have a way to get the topic name)
        String topicName = topics.getOrDefault(topicID, "Unknown Topic");
        String formattedMessage = String.format("[%s] [%s : %s : %s] %s", currentTime, topicID, topicName, publisherID, message);

        // Notify all local subscribers in real-time
        Set<SubscriberCallbackInterface> subscribers = topicSubscribers.getOrDefault(topicID, new HashSet<>());
        for (SubscriberCallbackInterface subscriber : subscribers) {
            try {
                // Send the formatted message to the subscriber
                subscriber.receiveMessage(formattedMessage);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }

        String timeStamp = getCurrentTimeStamp();
        System.out.println(String.format("[%s] [SUCCESS] Message from %s published to topic %s and forwarded to local subscribers.", timeStamp, publisherID, topicID));
        
        // Now propagate the message to all connected brokers for global synchronization
        propagateMessageToOtherBrokers(topicID, formattedMessage, publisherID);
    }

    // Method to propagate messages to all connected brokers
    private void propagateMessageToOtherBrokers(String topicID, String message, String publisherID) {
        for (Map.Entry<String, BrokerInterface> entry : connectedBrokers.entrySet()) {
            BrokerInterface remoteBroker = entry.getValue();
            try {
                // Use syncMessage to propagate the message to other brokers
                remoteBroker.syncMessage(topicID, message);
            } catch (RemoteException e) {
                System.out.println("[ERROR] Failed to sync message with broker " + entry.getKey());
                e.printStackTrace();
            }
        }
    }

    // Synchronize messages between brokers
    @Override
    public synchronized void syncMessage(String topicID, String message) throws RemoteException {
        // Check if we have any local subscribers for this topic
        Set<SubscriberCallbackInterface> localSubscribers = topicSubscribers.getOrDefault(topicID, new HashSet<>());

        if (!localSubscribers.isEmpty()) {
            // If there are local subscribers, deliver the message to them
            String timeStamp = getCurrentTimeStamp();
            System.out.println(String.format("[%s] [SUCCESS] Received message for topic %s from another broker. Delivering to local subscribers.", timeStamp, topicID));

            
            for (SubscriberCallbackInterface subscriber : localSubscribers) {
                try {
                    // Send the received message to the local subscriber
                    subscriber.receiveMessage(message);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
        } else {
            String timeStamp = getCurrentTimeStamp();
            System.out.println(String.format("[%s] [SUCCESS] No local subscribers for topic %s. Ignoring message.", timeStamp, topicID));

        }
    }

    // Subscribe to a topic with callback mechanism and synchronization
    @Override
    public synchronized void subscribeToTopicWithCallback(String topicID, String subscriberID, SubscriberCallbackInterface callback) throws RemoteException {
        // Ensure the topic exists
        if (!remoteTopics.containsKey(topicID) && !topics.containsKey(topicID)) {
            throw new RemoteException("Topic " + topicID + " does not exist.");
        }

        // Check if the user is already subscribed to this topic
        Set<String> userSubscriptions = subscriberTopics.getOrDefault(subscriberID, new HashSet<>());
        if (userSubscriptions.contains(topicID)) {
            throw new RemoteException("You are already subscribed to topic " + topicID + ".");
        }

        // Synchronize the block that modifies the topicSubscribers map
        synchronized (topicSubscribers) {
            topicSubscribers.computeIfAbsent(topicID, k -> new HashSet<>()).add(callback);
        }

        // Also update the subscriberTopics map for tracking purposes
        synchronized (subscriberTopics) {
            subscriberTopics.computeIfAbsent(subscriberID, k -> new HashSet<>()).add(topicID);
        }

        if (topics.containsKey(topicID)) {
            String timeStamp = getCurrentTimeStamp();
            System.out.println(String.format("[%s] [SUCCESS] Subscriber %s registered for topic %s.", timeStamp, subscriberID, topicID));
        } else if (remoteTopics.containsKey(topicID)) {
            for (Map.Entry<String, BrokerInterface> entry : connectedBrokers.entrySet()) {
                BrokerInterface remoteBroker = entry.getValue();
                if (remoteBroker.getTopics().containsKey(topicID)) {
                    String timeStamp = getCurrentTimeStamp();
                    String message = String.format("[%s] [SUCCESS] Subscriber %s registered for topic %s.", timeStamp, subscriberID, topicID);
                    remoteBroker.notifyRemoteBroker(message);
                }
            }
        }
    }

    // Get the topics map
    @Override
    public Map<String, String> getTopics() {
        return topics;
    }

    // Unsubscribe a subscriber from a topic
    @Override
    public synchronized void unsubscribeFromTopic(String topicID, String subscriberID) throws RemoteException {
        // Ensure the topic exists
        if (!remoteTopics.containsKey(topicID) && !topics.containsKey(topicID)) {
            throw new RemoteException("Topic " + topicID + " does not exist.");
        }

        // Check if the user is subscribed to this topic
        Set<String> userSubscriptions = subscriberTopics.getOrDefault(subscriberID, new HashSet<>());
        if (!userSubscriptions.contains(topicID)) {
            throw new RemoteException("You are already unsubscribed from topic " + topicID + ".");
        }

        // Remove the topic from the user's subscription list
        userSubscriptions.remove(topicID);

        // Also remove the subscriber's callback from the topicSubscribers map
        synchronized (topicSubscribers) {
            Set<SubscriberCallbackInterface> subscribers = topicSubscribers.get(topicID);
            if (subscribers != null) {
                subscribers.removeIf(callback -> {
                    try {
                        return callback.getSubscriberID().equals(subscriberID);  // Assuming getSubscriberID() throws RemoteException
                    } catch (RemoteException e) {
                        e.printStackTrace();
                        return false;  // If there's an error, don't remove the callback
                    }
                });

                // If there are no more subscribers for the topic, remove the entry
                if (subscribers.isEmpty()) {
                    topicSubscribers.remove(topicID);
                }
            }
        }

        if (topics.containsKey(topicID)) {
            String timeStamp = getCurrentTimeStamp();
            System.out.println(String.format("[%s] [SUCCESS] Subscriber %s unregistered for topic %s.", timeStamp, subscriberID, topicID));
        } else if (remoteTopics.containsKey(topicID)) {
            for (Map.Entry<String, BrokerInterface> entry : connectedBrokers.entrySet()) {
                BrokerInterface remoteBroker = entry.getValue();
                if (remoteBroker.getTopics().containsKey(topicID)) {
                    String timeStamp = getCurrentTimeStamp();
                    String message = String.format("[%s] [SUCCESS] Subscriber %s unregistered for topic %s.", timeStamp, subscriberID, topicID);
                    remoteBroker.notifyRemoteBroker(message);
                }
            }
        }
    } 

    // Send back a unsubscribe confirmation message
    @Override
    public synchronized String sendUnsubscribeConfirmation(String topicID, String subscriberID) throws RemoteException {
        String topicName;
        String publisherID;

        if (topics.containsKey(topicID)) {
            // Retrieve necessary information for the message (e.g., topicName and publisherID)
            topicName = topics.getOrDefault(topicID, "Unknown Topic");
            publisherID = publisherTopics.entrySet().stream()
                .filter(entry -> entry.getValue().contains(topicID))
                .map(Map.Entry::getKey)
                .findFirst()
                .orElse("Unknown Publisher");
        } else if (remoteTopics.containsKey(topicID)) {
            // Retrieve necessary information for the message (e.g., topicName and publisherID)
            String[] remoteTopicDetails = remoteTopics.get(topicID);
            topicName = remoteTopicDetails[0];  // First element is topicName
            publisherID = remoteTopicDetails[1];  // Second element is publisherID
        } else {
            // If the topicID is not found in either map, handle it as "Unknown"
            topicName = "Unknown Topic";
            publisherID = "Unknown Publisher";
        }


        String timeStamp = getCurrentTimeStamp();
        String message = String.format("[%s] [%s : %s : %s] Your unsubscription has been confirmed by %s.", timeStamp, topicID, topicName, publisherID, publisherID);
        
        return message;
    }

    // Notify the remote broker the message
    @Override
    public synchronized void notifyRemoteBroker(String message) throws RemoteException {
        System.out.println(message);
    }

    // Handle publisher crash
    @Override
    public synchronized void handlePublisherCrash(String publisherID) throws RemoteException {
        // Remove the publisher from the active publishers list
        activePublishers.remove(publisherID);
        directoryService.decreaseConnectionCount(brokerID);
        System.out.println(String.format("[%s] [INFO] Publisher %s removed from active publishers due to crash.", getCurrentTimeStamp(), publisherID));

        // Check if the publisher exists and has topics
        Set<String> publisherTopicSet = publisherTopics.getOrDefault(publisherID, new HashSet<>());

        if (publisherTopicSet.isEmpty()) {
            System.out.println(String.format("[%s] [INFO] No topics found for publisher %s. Nothing to delete.", getCurrentTimeStamp(), publisherID));
            return;
        }

        // Iterate through all topics owned by this publisher and delete them
        for (String topicID : publisherTopicSet) {
            try {
                // Call the deleteTopic method to delete each topic and handle unsubscription of subscribers
                deleteTopic(topicID, publisherID);
                System.out.println(String.format("[%s] [SUCCESS] Topic %s deleted due to publisher %s crash.", getCurrentTimeStamp(), topicID, publisherID));
            } catch (RemoteException e) {
                System.out.println(String.format("[%s] [ERROR] Failed to delete topic %s for publisher %s.", getCurrentTimeStamp(), topicID, publisherID));
                e.printStackTrace();
            }
        }
    }

    // Handle subscriber crash
    @Override
    public synchronized void handleSubscriberCrash(String subscriberID) throws RemoteException {

        // Remove the subscriber from the subscriberTopics map
        activeSubscribers.remove(subscriberID);
        directoryService.decreaseConnectionCount(brokerID);
        System.out.println(String.format("[%s] [INFO] Subscriber %s removed from subscriber list due to crash.", getCurrentTimeStamp(), subscriberID));

        // Check if the subscriber exists and has subscriptions
        Set<String> subscribedTopics = subscriberTopics.getOrDefault(subscriberID, new HashSet<>());

        if (subscribedTopics.isEmpty()) {
            System.out.println(String.format("[%s] [INFO] No subscriptions found for subscriber %s. Nothing to remove.", getCurrentTimeStamp(), subscriberID));
            return;
        }

        // Unsubscribe the subscriber from all topics
        for (String topicID : subscribedTopics) {
            try {
                // Call the unsubscribeFromTopic method to remove the subscriber from the topic
                unsubscribeFromTopic(topicID, subscriberID);
                System.out.println(String.format("[%s] [SUCCESS] Subscriber %s unsubscribed from topic %s due to crash.", getCurrentTimeStamp(), subscriberID, topicID));
            } catch (RemoteException e) {
                System.out.println(String.format("[%s] [ERROR] Failed to unsubscribe subscriber %s from topic %s.", getCurrentTimeStamp(), subscriberID, topicID));
                e.printStackTrace();
            }
        }
    }

    // Get the list of available topics
    @Override
    public synchronized List<String[]> getAvailableTopics() throws RemoteException {
        List<String[]> topicList = new ArrayList<>();
        for (Map.Entry<String, String> entry : topics.entrySet()) {
            String topicID = entry.getKey();
            String topicName = entry.getValue();

            // Find publisher of the topic
            String publisherID = publisherTopics.entrySet().stream()
                .filter(e -> e.getValue().contains(topicID))
                .map(Map.Entry::getKey)
                .findFirst()
                .orElse("Unknown Publisher");

            topicList.add(new String[] { topicID, topicName, publisherID });
        }
        return topicList;
    }

    // Get the list of available topics across the broker network
    @Override
    public synchronized List<String[]> getAvailableTopicsFromOtherBrokers() throws RemoteException {
        List<String[]> remoteTopicList = new ArrayList<>();
    
        // Retrieve topics from other connected brokers using RMI
        for (Map.Entry<String, BrokerInterface> entry : connectedBrokers.entrySet()) {
            BrokerInterface remoteBroker = entry.getValue();
            try {
                // Fetch topics from the remote broker
                List<String[]> remoteTopics = remoteBroker.getAvailableTopics();
                // Add the remote topics to the list
                remoteTopicList.addAll(remoteTopics);
            } catch (RemoteException e) {
                System.out.println("[ERROR] Failed to fetch topics from broker " + entry.getKey());
                e.printStackTrace();
            }
        }
    
        return remoteTopicList;
    }
    
    // Get the subscriber count for a topic
    @Override
    public synchronized List<String[]> getSubscriberCountForPublisher(String publisherID) throws RemoteException {
        List<String[]> topicSubscriberCounts = new ArrayList<>();
        Set<String> publisherTopicSet = publisherTopics.getOrDefault(publisherID, new HashSet<>());

        for (String topicID : publisherTopicSet) {
            String topicName = topics.getOrDefault(topicID, "Unknown Topic");

            // Count the number of subscribers for this topic
            long subscriberCount = subscriberTopics.entrySet().stream()
                .filter(entry -> entry.getValue().contains(topicID))
                .count();

            for (Map.Entry<String, BrokerInterface> entry : connectedBrokers.entrySet()) {
                BrokerInterface remoteBroker = entry.getValue();
                try {
                    // Fetch the subscriber count for this topic from the remote broker
                    long remoteSubscriberCount = remoteBroker.getSubscriberCountForTopic(topicID);
                    subscriberCount += remoteSubscriberCount;
                } catch (RemoteException e) {
                    System.out.println("[ERROR] Failed to fetch topics from broker " + entry.getKey());
                    e.printStackTrace();
                }
            }

            topicSubscriberCounts.add(new String[] { topicID, topicName, String.valueOf(subscriberCount) });
        }

        return topicSubscriberCounts;
    }

    // Get the subscriber count for a specific topic
    @Override
    public synchronized long getSubscriberCountForTopic(String topicID) throws RemoteException {
        // Count the number of subscribers for this topic
        long subscriberCount = subscriberTopics.entrySet().stream()
        .filter(entry -> entry.getValue().contains(topicID))
        .count();
        return subscriberCount;
    }

    // Get the subscriber topics map
    @Override
    public Map<String, Set<String>> getSubscriberTopics() {
        return subscriberTopics;
    }

    // Get the subscriptions of a subscriber
    @Override
    public synchronized List<String[]> getCurrentSubscriptions(String subscriberID) throws RemoteException {
        List<String[]> subscriptionList = new ArrayList<>();
        Set<String> subscribedTopics = subscriberTopics.getOrDefault(subscriberID, new HashSet<>());

        for (String topicID : subscribedTopics) {
            String topicName;
            String publisherID;

            // Check if the topicID is in the local topics map
            if (topics.containsKey(topicID)) {
                topicName = topics.get(topicID);

                // Find the local publisher for this topic
                publisherID = publisherTopics.entrySet().stream()
                    .filter(entry -> entry.getValue().contains(topicID))
                    .map(Map.Entry::getKey)
                    .findFirst()
                    .orElse("Unknown Publisher");

            // Check if the topicID is in the remoteTopics map
            } else if (remoteTopics.containsKey(topicID)) {
                String[] remoteTopicDetails = remoteTopics.get(topicID);
                topicName = remoteTopicDetails[0];  // First element is topicName
                publisherID = remoteTopicDetails[1];  // Second element is publisherID

            } else {
                // If the topicID is not found in either map, handle it as "Unknown"
                topicName = "Unknown Topic";
                publisherID = "Unknown Publisher";
            }

            subscriptionList.add(new String[] { topicID, topicName, publisherID });
        }

        return subscriptionList;
    }

    // Test method for inter-broker communication
    @Override
    public synchronized void sendTestMessage(String message) throws RemoteException {
        System.out.println("Received test message: " + message + " at broker: " + brokerID);
    }

    // Method to add a new broker to the connected brokers list
    @Override
    public synchronized void addBroker(String newBrokerID, String newBrokerAddress) throws RemoteException {
        try {
            // Connect to the new broker via RMI and store the reference
            BrokerInterface newBroker = (BrokerInterface) Naming.lookup("//" + newBrokerAddress + "/BrokerService");
            connectedBrokers.put(newBrokerAddress, newBroker);

            String timeStamp = getCurrentTimeStamp();
            System.out.println("========================================");
            System.out.println(String.format("[%s] [INFO] Connected to new broker: %s at address: %s", timeStamp, newBrokerID, newBrokerAddress));
            System.out.println("========================================");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Implement the getBrokerID method
    @Override
    public synchronized String getBrokerID() throws RemoteException {
        return brokerID;
    }

    // Main method to start the broker
     public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println("[ERROR] Usage: java -jar broker.jar <brokerID> <brokerAddress>");
            return;
        }

        String brokerID = args[0];
        String brokerAddress = args[1];

        try {
            // Start RMI registry for broker on dynamic port
            LocateRegistry.createRegistry(Integer.parseInt(brokerAddress.split(":")[1]));

            // Create broker instance and bind to RMI registry
            Broker broker = new Broker(brokerID, brokerAddress);
            Naming.rebind("//" + brokerAddress + "/BrokerService", broker);

            // Register with DirectoryService
            broker.registerWithDirectoryService();

            String timeStamp = getCurrentTimeStamp();
            System.out.println("========================================");
            System.out.println(String.format("[%s] [INFO] Broker %s is running...", timeStamp, brokerID));
            System.out.println("========================================");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

