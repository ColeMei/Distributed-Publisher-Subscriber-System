package colemei.pubsubsystem.broker;

/**
 * Interface defining the broker operations in the publish-subscribe system.
 * Provides methods for publisher and subscriber registration, topic management, 
 * and message propagation between brokers.
 * 
 * @author QIYUE MEI 1554024
 */

import colemei.pubsubsystem.subscriber.SubscriberCallbackInterface;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface BrokerInterface extends Remote {

    // To update the list of active publishers connected to the broker
    void registerPublisher(String username) throws RemoteException;

    // To update the list of active subscribers connected to the broker
    void registerSubscriber(String username) throws RemoteException;

    // To ungister a publisher from the list of active publishers
    void unregisterPublisher(String username) throws RemoteException;

    // To unregister a subscriber from the list of active subscribers
    void unregisterSubscriber(String username) throws RemoteException;
    
    // Register a new topic
    void registerTopic(String topicID, String topicName, String publisherName) throws RemoteException;

    // Add a remote topic to the local broker
    void addRemoteTopic(String topicID, String topicName, String publisherName) throws RemoteException;

    // Delete a topic and notify subscribers
    void deleteTopic(String topicID, String username) throws RemoteException;

    // Delete a remote topic
    void deleteRemoteTopic(String topicID) throws RemoteException;

    // Publish a message to a topic and return the messages to be sent to each subscriber
    void publishMessage(String topicID, String message, String publisherID) throws RemoteException;

    // Synchronize messages between brokers
    void syncMessage(String topicID, String message) throws RemoteException;

    // Subscribe a subscriber to a topic
    void subscribeToTopicWithCallback(String topicID, String subscriberID, SubscriberCallbackInterface callback) throws RemoteException;

    // Unsubscribe a subscriber from a topic
    void unsubscribeFromTopic(String topicID, String subscriberID) throws RemoteException;

    // Send back a confirmation to the subscriber
    String sendUnsubscribeConfirmation(String topicID, String subscriberID) throws RemoteException;

    // Get the topics map
    Map<String, String> getTopics() throws RemoteException;

    // Notify a message to a remote broker
    void notifyRemoteBroker(String message) throws RemoteException;

    // Handle publisher crash by deleting their topics
    void handlePublisherCrash(String publisherID) throws RemoteException;

    // Handle subscriber crash by removing subscriptions
    void handleSubscriberCrash(String subscriberID) throws RemoteException;

    // Get the list of available topics on the local broker
    List<String[]> getAvailableTopics() throws RemoteException;

    // Get the list of available topics across the broker network
    List<String[]> getAvailableTopicsFromOtherBrokers() throws RemoteException;

    // Get subscriber count for each topic created by a publisher
    List<String[]> getSubscriberCountForPublisher(String publisherID) throws RemoteException;

    // Get subscriber count for a specific topic
    long getSubscriberCountForTopic(String topicID) throws RemoteException;

    // Get the list of subscribers for a topic
    Map<String, Set<String>> getSubscriberTopics() throws RemoteException;

    // Get the list of topics a subscriber is subscribed to
    List<String[]> getCurrentSubscriptions(String subscriberID) throws RemoteException;

    // Method to add a new broker to the connected brokers list
    void addBroker(String brokerID, String brokerAddress) throws RemoteException;
    
    // Test method for inter-broker communication
    void sendTestMessage(String message) throws RemoteException;

    // Method to get the unique broker ID
    String getBrokerID() throws RemoteException;
}
