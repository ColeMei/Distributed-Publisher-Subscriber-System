package colemei.pubsubsystem.subscriber;

/**
 * Interface for the subscriber callback mechanism, allowing brokers to send real-time 
 * messages to subscribers. Provides a method to receive messages and retrieve the 
 * subscriber's ID.
 * 
 * @author QIYUE MEI 1554024
 */


import java.rmi.Remote;
import java.rmi.RemoteException;

public interface SubscriberCallbackInterface extends Remote {
    // Method to send a message to the subscriber
    void receiveMessage(String message) throws RemoteException;

    // Method to get the subscriber ID
    String getSubscriberID() throws RemoteException;
}

