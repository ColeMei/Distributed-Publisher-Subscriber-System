package colemei.pubsubsystem.subscriber;

/**
 * The Subscriber class represents a subscriber in the publish-subscribe system.
 * It connects to a broker to subscribe to topics, receive messages, and manage 
 * its subscriptions. It supports real-time notifications via callback and handles 
 * graceful shutdown and crash detection.
 * 
 * @author QIYUE MEI 1554024
 */

import colemei.pubsubsystem.broker.BrokerInterface;
import colemei.pubsubsystem.directory.DirectoryServiceInterface;
import colemei.pubsubsystem.util.Constants;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Subscriber extends UnicastRemoteObject implements SubscriberCallbackInterface {

    private String username;
    private BrokerInterface connectedBroker;
    private DirectoryServiceInterface directoryService;

    private final Scanner scanner = new Scanner(System.in);

    private boolean gracefulExit = false;  // Flag to track if the exit was graceful

    // Constructor
    public Subscriber(String username) throws RemoteException {
        this.username = username;
        connectToDirectoryService();
    }

    // Connect to the Directory Service
    private void connectToDirectoryService() {
        try {
            directoryService = (DirectoryServiceInterface) Naming.lookup(Constants.DIRECTORY_SERVICE_URL);
            System.out.println("[SUCCESS] Connected to Directory Service");
        } catch (Exception e) {
            System.out.println("[ERROR] Failed to connect to Directory Service.");
            e.printStackTrace();
        }
    }

    // Connect to the least busy broker
    private void connectToBroker() {
        try {
            // Retrieve the least busy broker as a String array [brokerID, brokerAddress]
            String[] availableBroker = directoryService.getLeastBusyBroker();
    
            // Debugging: print out the least busy broker
            if (availableBroker != null) {
                String brokerID = availableBroker[0];  // Extract brokerID
                String brokerAddress = availableBroker[1];  // Extract brokerAddress
    
                connectedBroker = (BrokerInterface) Naming.lookup("//" + brokerAddress + "/BrokerService");

                // Register this subscriber with the broker
                connectedBroker.registerSubscriber(username);
    
                // Inform DirectoryService that a new connection has been made
                directoryService.increaseConnectionCount(brokerID);
    
                System.out.println("[SUCCESS] " + username + " connected to broker: " + brokerID + " at address: " + brokerAddress);
            } else {
                System.out.println("[ERROR] No available brokers at the moment.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // List available brokers and let the publisher choose one to connect
    private void listAvailableBrokers() {
        try {
            // Retrieve the list of available brokers as a list of String arrays [brokerID, brokerAddress]
            List<String[]> brokers = directoryService.getAvailableBrokers();
            
            if (brokers.isEmpty()) {
                System.out.println("[INFO] No available brokers at the moment.");
                return;
            }

            System.out.println("[INFO] Available brokers:");
            for (int i = 0; i < brokers.size(); i++) {
                String[] broker = brokers.get(i);
                System.out.println(i + 1 + ". Broker ID: " + broker[0] + ", Address: " + broker[1]);
            }

            // Prompt the publisher to select a broker
            System.out.print("> Select a broker to connect (enter the index): ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume the newline

            if (choice > 0 && choice <= brokers.size()) {
                String brokerID = brokers.get(choice - 1)[0];
                String brokerAddress = brokers.get(choice - 1)[1];
                connectToSpecifiedBroker(brokerID, brokerAddress);
            } else {
                System.out.println("[ERROR] Invalid selection.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Connect to the specified broker by name
    private void connectToSpecifiedBroker(String brokerName) {
        try {
            // Retrieve the broker's address from the Directory Service by name
            String[] brokerInfo = directoryService.getBrokerInfoByName(brokerName);

            if (brokerInfo != null) {
                String brokerID = brokerInfo[0];
                String brokerAddress = brokerInfo[1];

                connectedBroker = (BrokerInterface) Naming.lookup("//" + brokerAddress + "/BrokerService");

                // Register this publisher with the broker
                connectedBroker.registerSubscriber(username);

                // Inform DirectoryService that a new connection has been made
                directoryService.increaseConnectionCount(brokerID);

                System.out.println("[SUCCESS] " + username + " connected to broker: " + brokerID + " at address: " + brokerAddress);
            } else {
                System.out.println("[ERROR] No broker found with the name: " + brokerName);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Overloaded connectToSpecifiedBroker method for broker ID and address directly
    private void connectToSpecifiedBroker(String brokerID, String brokerAddress) {
        try {
            connectedBroker = (BrokerInterface) Naming.lookup("//" + brokerAddress + "/BrokerService");

            // Register this publisher with the broker
            connectedBroker.registerSubscriber(username);

            // Inform DirectoryService that a new connection has been made
            directoryService.increaseConnectionCount(brokerID);

            System.out.println("[SUCCESS] " + username + " connected to broker: " + brokerID + " at address: " + brokerAddress);
        } catch (Exception e) {
            e.printStackTrace();
        }
    } 
    
    // Implementation of the callback method to receive messages
    @Override
    public void receiveMessage(String message) throws RemoteException {
        // This method will be called by the broker when a message is published
        System.out.println();
        System.out.println(message);
    }

    // Implementation of the callback method to get the subscriber ID
    @Override
    public String getSubscriberID() throws RemoteException {
        return username;
    }

    // Console interface for the Subscriber
    private void runConsoleInterface() {

        // Register the shutdown hook to detect forceful termination (like Ctrl+C)
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                // If this is a forceful shutdown (not via the "exit" command)
                if (!gracefulExit) {
                    System.out.println();
                    System.out.println("[INFO] Subscriber " + username + " is shutting down unexpectedly. Notifying broker...");
                    connectedBroker.handleSubscriberCrash(username);  // Notify the broker about the subscriber shutdown
                } 
            } catch (RemoteException e) {
                System.out.println("[ERROR] Failed to notify broker about subscriber crash.");
                e.printStackTrace();
            }
        }));

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nPlease select a command: list, sub, current, unsub, or exit.");
            System.out.println("1. list                            # List all topics");
            System.out.println("2. sub {topic_id}                  # Subscribe to a topic");
            System.out.println("3. current                         # Show current subscriptions");
            System.out.println("4. unsub {topic_id}                # Unsubscribe from a topic");
            System.out.println("5. exit                            # Exit the subscriber");
            System.out.print("> Enter command: ");

            String command = scanner.nextLine().trim();

            switch (command.split(" ")[0]) {
                case "list":
                    handleListTopics();
                    break;
                case "sub":
                    handleSubscribe(command);
                    break;
                case "current":
                    handleShowSubscriptions();
                    break;
                case "unsub":
                    handleUnsubscribe(command);
                    break;
                case "exit":
                    handleExit();
                    return;
                default:
                    System.out.println("[ERROR] Invalid command.");
            }
        }
    }

    // Get the list of topics from the broker
    private void handleListTopics() {
        try {
            // Fetch the list of local topics from the connected broker
            List<String[]> localTopics = connectedBroker.getAvailableTopics();
            
            // Fetch the list of remote topics from other brokers
            List<String[]> remoteTopics = connectedBroker.getAvailableTopicsFromOtherBrokers();

            // Combine both local and remote topics
            List<String[]> allTopics = new ArrayList<>(localTopics);
            allTopics.addAll(remoteTopics);

            if (allTopics.isEmpty()) {
                System.out.println("[SUCCESS] No topics available.");
            } else {
                System.out.println("[SUCCESS] Available topics:");
                for (String[] topic : allTopics) {
                    System.out.println("Topic ID: " + topic[0] + ", Topic Name: " + topic[1] + ", Publisher: " + topic[2]);
                }
            }
        } catch (RemoteException e) {
            System.out.println("[ERROR] Could not retrieve topic list.");
            e.printStackTrace();
        } catch (Exception e) {
            System.out.println("[ERROR] Could not retrieve topic list.");
            e.printStackTrace();
        }
    }
    
    // Subscribe to a topic
    private void handleSubscribe(String command) {
        try {
            // Parse command to get topic ID
            String[] parts = command.split(" ");
            if (parts.length != 2) {
                System.out.println("[ERROR] Invalid command format. Use: sub {topic_id}");
                return;
            }
            String topicID = parts[1];
    
            // Register for real-time notifications via callback
            connectedBroker.subscribeToTopicWithCallback(topicID, username, this);
            System.out.println("[SUCCESS] Subscribed to topic: " + topicID);
        } catch (RemoteException e) {
            String errorMessage = e.getMessage();
            if (errorMessage.contains("does not exist")) {
                System.out.println("[ERROR] " + errorMessage);
            } else if (errorMessage.contains("already subscribed to topic")) {
                System.out.println("[ERROR] " + errorMessage);
            } else {
                // General RemoteException handler
                System.out.println("[ERROR] Failed to subscribe due to a remote error.");
                e.printStackTrace();
            }
        } catch (Exception e) {
            // General exception handler for any other unexpected issues
            System.out.println("[ERROR] An unexpected error occurred.");
            e.printStackTrace();
        }
    }
    
    // Show the current subscriptions
    private void handleShowSubscriptions() {
        try {
            // Request the broker to show the current subscriptions
            List<String[]> subscriptions = connectedBroker.getCurrentSubscriptions(username);
            if (subscriptions.isEmpty()) {
                System.out.println("[SUCCESS] No active subscriptions.");
            } else {
                System.out.println("[SUCCESS] Active subscriptions:");
                for (String[] sub : subscriptions) {
                    System.out.println("Topic ID: " + sub[0] + ", Topic Name: " + sub[1] + ", Publisher: " + sub[2]);
                }
            }
        } catch (Exception e) {
            System.out.println("[ERROR] Could not retrieve subscriptions.");
            e.printStackTrace();
        }
    }
    
    // Unsubscribe from a topic
    private void handleUnsubscribe(String command) {
        try {
            // Parse command to get topic ID
            String[] parts = command.split(" ");
            if (parts.length != 2) {
                System.out.println("[ERROR] Invalid command format. Use: unsub {topic_id}");
                return;
            }
            String topicID = parts[1];
    
            // Request the broker to unsubscribe from the topic
            connectedBroker.unsubscribeFromTopic(topicID, username);
            String confirmation = connectedBroker.sendUnsubscribeConfirmation(topicID, username);
            System.out.println("[SUCCESS] Unsubscribed from topic: " + topicID);
            System.out.println(confirmation);
        } catch (RemoteException e) {
            String errorMessage = e.getMessage();
            if (errorMessage.contains("does not exist")) {
                System.out.println("[ERROR] " + errorMessage);
            } else if (errorMessage.contains("already unsubscribed to topic")) {
                System.out.println("[ERROR] " + errorMessage);
            } else {
                // General RemoteException handler
                System.out.println("[ERROR] Failed to unsubscribe due to a remote error.");
                e.printStackTrace();
            }
        } catch (Exception e) {
            // General exception handler for any other unexpected issues
            System.out.println("[ERROR] An unexpected error occurred.");
            e.printStackTrace();
        }
    }
    
    // Exit the subscriber
    private void handleExit() {
        try {
            if (connectedBroker != null) {
                gracefulExit = true;  // Mark as graceful exit
                connectedBroker.unregisterSubscriber(username);
                System.out.println("[SUCCESS] Successfully unregistered from broker.");
            }
            System.out.println("Exiting...");
        } catch (RemoteException e) {
            System.out.println("[ERROR] Error during unregistering with broker.");
            e.printStackTrace();

        }catch (Exception e) {
            System.out.println("[ERROR] Error during unregistering with broker.");
            e.printStackTrace();
        }
        System.exit(0);  // Normal exit
    }
    
    // Main method to run the Subscriber
    public static void main(String[] args) {
    	try {
	        if (args.length < 1 || args.length > 3) {
                System.out.println("[ERROR] Usage:");
                System.out.println("  java -jar subscriber.jar <username>                      # Auto-connect to least busy broker");
                System.out.println("  java -jar subscriber.jar <username> <-list>              # List available brokers");
                System.out.println("  java -jar subscriber.jar <username> <brokername>         # Connect to specified broker");
                return;
            }
	
	        String username = args[0];
	        Subscriber subscriber = new Subscriber(username);
            
            if (args.length == 1) {
                // Auto-connect to least busy broker
                subscriber.connectToBroker();
            } else if (args.length == 2 && args[1].equals("-list")) {
                // List available brokers
                subscriber.listAvailableBrokers();
            } else if (args.length == 2) {
                // Connect to specified broker
                String brokerName = args[1];
                subscriber.connectToSpecifiedBroker(brokerName);
            }

	        // Run the console interface
	        subscriber.runConsoleInterface();

    	} catch (Exception e) {
            e.printStackTrace();
        }
    }
}
