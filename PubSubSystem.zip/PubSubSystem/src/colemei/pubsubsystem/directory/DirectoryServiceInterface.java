package colemei.pubsubsystem.directory;

/**
 * Interface for the Directory Service, which tracks available brokers and their 
 * load in the distributed system. Provides methods to retrieve the least busy broker
 * and manage broker connection counts.
 * 
 * @author QIYUE MEI 1554024
 */


import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

public interface DirectoryServiceInterface extends Remote {
    
    // Register a broker with the directory service
    void registerBroker(String brokerID, String brokerAddress) throws RemoteException;

    // Retrieve a map of all registered brokers (brokerID -> brokerAddress)
    Map<String, String> getRegisteredBrokers() throws RemoteException;

    // Unregister a broker
    void unregisterBroker(String brokerID) throws RemoteException;

    // Increase the connection count for a broker
    void increaseConnectionCount(String brokerID) throws RemoteException;

    // Decrease the connection count for a broker
    void decreaseConnectionCount(String brokerID) throws RemoteException;

    // Get the least busy broker based on connection count
    String[] getLeastBusyBroker() throws RemoteException;

    // Get a list of available brokers
    List<String[]> getAvailableBrokers() throws RemoteException;

    // Get broker information by name
    String[] getBrokerInfoByName(String brokerName) throws RemoteException;
}