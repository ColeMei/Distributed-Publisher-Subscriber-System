package colemei.pubsubsystem.directory;

/**
 * The DirectoryService class implements the DirectoryServiceInterface and provides 
 * the functionality to manage a list of available brokers and their respective loads.
 * It allows publishers and subscribers to connect to the least busy broker in the system.
 * 
 * @author QIYUE MEI 1554024
 */

import colemei.pubsubsystem.util.Constants;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DirectoryService extends UnicastRemoteObject implements DirectoryServiceInterface {

    // Store broker information and connection count
    private Map<String, BrokerStatus> brokerRegistry;

    // Constructor
    public DirectoryService() throws RemoteException {
        super();
        brokerRegistry = new HashMap<>();
    }

    // Helper method to get the current timestamp
    private static String getCurrentTimeStamp() {
        return new SimpleDateFormat("dd/MM HH:mm:ss").format(new Date());
    }

    // Implement methods from DirectoryServiceInterface
    @Override
    public synchronized void registerBroker(String brokerID, String brokerAddress) throws RemoteException {
        brokerRegistry.put(brokerID, new BrokerStatus(brokerAddress, 0));
        String timeStamp = getCurrentTimeStamp();
        System.out.println("========================================");
        System.out.println(String.format("[%s] [INFO] Broker registered: %s at %s", timeStamp, brokerID, brokerAddress));
        System.out.println("========================================");

    }

    // Get a map of registered brokers
    @Override
    public synchronized Map<String, String> getRegisteredBrokers() throws RemoteException {
        // Return a map of broker IDs to broker addresses
        Map<String, String> brokers = new HashMap<>();
        for (String brokerID : brokerRegistry.keySet()) {
            brokers.put(brokerID, brokerRegistry.get(brokerID).getAddress());
        }
        return brokers;
    }

    // increaseConnectionCount and decreaseConnectionCount methods to update the connection count of a broker
    @Override
    public synchronized void increaseConnectionCount(String brokerID) throws RemoteException {
        BrokerStatus brokerStatus = brokerRegistry.get(brokerID);

        if (brokerStatus != null) {
            brokerStatus.increaseConnectionCount();
            String timeStamp = getCurrentTimeStamp();
            System.out.println("========================================");
            System.out.println(String.format("[%s] [INFO] Broker %s connection count increased to %d", timeStamp, brokerID, brokerStatus.getConnectionCount()));
            System.out.println("========================================");

        }
    }

    @Override
    public synchronized void decreaseConnectionCount(String brokerID) throws RemoteException {
        BrokerStatus brokerStatus = brokerRegistry.get(brokerID);
        if (brokerStatus != null) {
            brokerStatus.decreaseConnectionCount();
            String timeStamp = getCurrentTimeStamp();
            System.out.println("========================================");
            System.out.println(String.format("[%s] [INFO] Broker %s connection count decreased to %d", timeStamp, brokerID, brokerStatus.getConnectionCount()));
            System.out.println("========================================");

        }
    }

    // Get the least busy broker
    @Override
    public synchronized String[] getLeastBusyBroker() throws RemoteException {
        // Sort brokers by connection count and return the least busy one (brokerID and brokerAddress)
        return brokerRegistry.entrySet().stream()
                .min((entry1, entry2) -> Integer.compare(entry1.getValue().getConnectionCount(), entry2.getValue().getConnectionCount()))
                .map(entry -> new String[] { entry.getKey(), entry.getValue().getAddress() })  // Return brokerID and brokerAddress in a String array
                .orElse(null);  // Return null if no brokers are available
    }


    // Unregister a broker in case of shutdown or failure
    @Override
    public synchronized void unregisterBroker(String brokerID) throws RemoteException {
        brokerRegistry.remove(brokerID);
        String timeStamp = getCurrentTimeStamp();
        System.out.println("========================================");
        System.out.println(String.format("[%s] [INFO] Broker unregistered: %s", timeStamp, brokerID));
        System.out.println("========================================");
    }

    @Override
    public List<String[]> getAvailableBrokers() throws RemoteException {
        List<String[]> availableBrokers = new ArrayList<>();

        // Iterate through the broker registry and add available brokers to the list
        for (Map.Entry<String, BrokerStatus> entry : brokerRegistry.entrySet()) {
            BrokerStatus brokerStatus = entry.getValue();
            String brokerID = entry.getKey();
            String brokerAddress = brokerStatus.getAddress();

            // Add broker information to the available brokers list
            availableBrokers.add(new String[] { brokerID, brokerAddress });
        }

        return availableBrokers;
    }
    
    @Override
    public String[] getBrokerInfoByName(String brokerName) throws RemoteException {
        // Check if the broker exists in the registry
        BrokerStatus brokerStatus = brokerRegistry.get(brokerName);

        if (brokerStatus != null) {
            // Return the brokerID and brokerAddress as a String array
            return new String[] { brokerName, brokerStatus.getAddress() };
        }

        // Return null if the broker is not found
        return null;
    }

    // Main method to start DirectoryService
    public static void main(String[] args) {
        try {
            // Start RMI registry on port 1099
            LocateRegistry.createRegistry(Constants.DEFAULT_PORT);

            // Create and bind the DirectoryService
            DirectoryService directoryService = new DirectoryService();
            Naming.rebind(Constants.DIRECTORY_SERVICE_URL, directoryService);

            String timeStamp = getCurrentTimeStamp();
            System.out.println("========================================");
            System.out.println(String.format("[%s] [INFO] Directory Service is running and ready...", timeStamp));
            System.out.println("========================================");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Inner class to hold broker connection count
    private class BrokerStatus {
        private String address;
        private int connectionCount;

        public BrokerStatus(String address, int connectionCount) {
            this.address = address;
            this.connectionCount = connectionCount;
        }

        public String getAddress() {
            return address;
        }

        public int getConnectionCount() {
            return connectionCount;
        }

        public void increaseConnectionCount() {
            connectionCount++;
        }

        public void decreaseConnectionCount() {
            connectionCount--;
        }
    }
}
