/**
 * 
 */
/**
 * 
 */
module PubSubSystem {
	requires java.rmi;
	
	exports colemei.pubsubsystem.directory to java.rmi;
    exports colemei.pubsubsystem.broker to java.rmi;
    exports colemei.pubsubsystem.publisher to java.rmi;
    exports colemei.pubsubsystem.subscriber to java.rmi;
}